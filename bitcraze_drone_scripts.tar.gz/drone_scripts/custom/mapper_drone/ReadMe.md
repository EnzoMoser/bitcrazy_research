The main script to run is "main.py"
Make sure to read the script to understand how it works before running.
Make sure the drone is equipped with the Flow Deck motion sensor, and any deck that provides an absolute positioning system.
If the map has changed, make sure to delete the png file to rerun the mapping sequence. Make sure to also mark the starting coordinate for the drone, and place it exactly there when launching the script the second time to make the drone move between the coordinates dynamically, forever.
