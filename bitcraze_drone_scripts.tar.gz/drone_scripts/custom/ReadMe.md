All of my custom scripts to test the functionality of the drone
