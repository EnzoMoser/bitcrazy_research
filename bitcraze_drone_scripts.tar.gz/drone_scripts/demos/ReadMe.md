These are official Bitcraze demos that can be found from their github: https://github.com/bitcraze
